#! /usr/bin/python

from mpi4py import MPI
try:
    from pypastix import MURGE
except Exception:
    try:
        from pyhips import MURGE
    except Exception:
        raise

import numpy as np

# ... MPI Initialization
size = MPI.COMM_WORLD.Get_size()
rank = MPI.COMM_WORLD.Get_rank()

null = MPI.COMM_NULL
comm = MPI.COMM_WORLD
# ...


root = -1
zero = 0
base = 1
dof = 1
tol = 1.e-7

murge = MURGE(nmatrices = 1)

id = 0
murge.SetDefaultOptions(id, zero)
#murge.SetOptionINT(id, MURGE.IParam.VERBOSE, API_VERBOSE_NOT)
#murge.SetOptionINT(id, MURGE.IParam.MATRIX_VERIFICATION, API_YES)

murge.SetOptionInt(id, MURGE.IParam.DOF, dof)
murge.SetOptionInt(id, MURGE.IParam.SYM, MURGE.Boolean.FALSE)
murge.SetOptionInt(id, MURGE.IParam.BASEVAL, base)

murge.SetOptionReal(id, MURGE.RParam.EPSILON_ERROR, tol)

rows = [1,4,2,3,4,4,3]
cols = [1,4,2,3,3,2,2]
V = [4,5,7,9,-1,1,-2]
edgenbr = len(rows)
n = 4

# ... Graph Initialization
if rank == 0:
    murge.GraphBegin(id, n, edgenbr)
    for i in range(0, edgenbr):
        print "i = ", i, rows[i], cols[i]
        murge.GraphEdge(id, rows[i], cols[i])
else:
    edgenbr = 0
    murge.GraphBegin(id, n, edgenbr)
murge.GraphEnd(id)
# ...

# ... Assembling
murge.MatrixReset(id)
murge.AssemblyBegin(  id, n, edgenbr \
                           , MURGE.AssemblyOp.ADD, MURGE.AssemblyOp.ADD \
                           , MURGE.AssemblyMode.FOOL, MURGE.Boolean.FALSE)

for i in range(0, edgenbr):
    murge.AssemblySetValue(id, rows[i], cols[i], V[i])

murge.AssemblyEnd(id)
# ...

murge.Clean(id)
