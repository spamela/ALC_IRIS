#!/bin/sh

if [ -e ".git" ]; then
    rev=`git rev-parse --short HEAD`;
    echo $rev;
    exit;
fi

if [ -f Revision ]
then
    cat ./Revision
else
    if [ -f ../../Revision ]
    then
	cat ../../Revision
    else
	echo "NoRevisionFound"
    fi
fi;
